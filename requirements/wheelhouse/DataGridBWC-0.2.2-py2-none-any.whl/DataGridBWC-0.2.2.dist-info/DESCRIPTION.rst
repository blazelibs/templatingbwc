DataGridBWC
======================

This module will be replaced by `WebGrid <https://pypi.python.org/pypi/WebGrid>`_.

Questions & Comments
---------------------

Please visit: http://groups.google.com/group/blazelibs

Source Code
---------------

The code is available from the `bitbucket repo <http://bitbucket.org/blazelibs/datagridbwc/>`_.

The `DataGridBWC tip <http://bitbucket.org/blazelibs/datagridbwc/get/tip.zip#egg=datagridbwc-dev>`_
is installable via `easy_install` with ``easy_install DataGridBWC==dev``


Change Log
----------

0.2.2 released 2014-08-27
===========================

* fix broken 0.2.1 release caused by .rst files not getting added to distribution

0.2.1 released 2014-08-25
===========================

* deprecate declarative functionality and depend on WebGrid

0.2.0 released 2014-08-20
===========================

* fix some tests
* update example url in settings.py
* cleanup setup.py
* refactored subtotaling feature
* workaround for dateutils parsing bug
* adjustments for SQLAlchemy 0.9+ (we now support 0.8+)


