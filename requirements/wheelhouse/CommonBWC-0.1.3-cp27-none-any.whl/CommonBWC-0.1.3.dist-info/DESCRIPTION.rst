Introduction
---------------

CommonBWC is a component for `BlazeWeb <http://pypi.python.org/pypi/BlazeWeb/>`_
applications.  It has views, classes, and templates that are common for many
web applications.

Questions & Comments
---------------------

Please visit: http://groups.google.com/group/blazelibs

Current Status
---------------

The code stays pretty stable, but the API is likely to change in the future.

The `CommonBWC tip <http://bitbucket.org/rsyring/commonbwc/get/tip.zip#egg=commonbwc-dev>`_
is installable via `easy_install` with ``easy_install commonbwc==dev``


Changelog
---------------

0.1.3 released 2011-06-11
=========================

* added SAValidation support to lib.forms.Form


