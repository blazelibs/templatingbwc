SQLAlchemyBWC
=============

.. image:: https://ci.appveyor.com/api/projects/status/kbon082l7ndao16q?svg=true
    :target: https://ci.appveyor.com/project/level12/sqlalchemybwc

.. image:: https://circleci.com/gh/blazelibs/sqlalchemybwc.svg?style=shield
    :target: https://circleci.com/gh/blazelibs/sqlalchemybwc

.. image:: https://codecov.io/gh/blazelibs/sqlalchemybwc/branch/master/graph/badge.svg
    :target: https://codecov.io/gh/blazelibs/sqlalchemybwc

Introduction
---------------

SQLAlchemyBWC is a component for `BlazeWeb <http://pypi.python.org/pypi/BlazeWeb/>`_
applications.

Questions & Comments
---------------------

Please visit: http://groups.google.com/group/blazelibs

Current Status
---------------

The code stays pretty stable, but the API may change in the future.

The `SQLAlchemyBWC tip <http://bitbucket.org/blazelibs/sqlalchemybwc/get/tip.zip#egg=sqlalchemybwc-dev>`_
is installable via `easy_install` with ``easy_install SQLAlchemyBWC==dev``


Change Log
===========

0.3.0 released 2016-11-29
--------------------------

- add support for Python 3 (3.4 and 3.5)
- set up continuous integration testing on CodeCov and AppVeyor
- test coverage is on CodeCov and includes sqlite, postgresql, and mssql

0.2.14 released 2016-02-23
--------------------------

- update FormEncode compatibility to include 1.3

0.2.13 released 2015-12-04
--------------------------

- update SQLAlchemy compatibility to prevent warnings

0.2.12 released 2015-10-05
--------------------------

 - add python_type property to SmallIntBool type
 - fix FK message detection on PostgreSQL with newer library versions.

0.2.11 released 2015-03-17
--------------------------

 - fixed bad MANIFEST.in from 0.2.10

0.2.10 released 2015-03-17
--------------------------

 - allow testing-related decorators/helpers to specify db for proper rollbacks
   and dialect message checks

0.2.9 released 2014-08-29
-------------------------

 - add auto-cleanup of beaker sessions for database storage (if applicable).
   settings.beaker.auto_clear_sessions (default True) controls this function
 - handle new format for SQLite null messages
 - restructure setup.py, version, readme, etc.

0.2.8 released 2014-07-08
-------------------------

 - fix problem when metadata "sticking" when using multiple databases
 - SQLAlchemyContainer can now handle None for a URL and won't throw an exception
 - add .lib.sql.SQLLoader() to be a more flexible option than the other functions in that module

0.2.7 released 2013-12-17
-------------------------

 - adjust declarative order_by_helper() to not assume an id column but use primary keys instead

0.2.6 released 2012-10-24
-------------------------

 - added assert_raises_*_exc() decorators for testing
 - update SAValidation dependency to >= 0.2.0

0.2.5 released 2011-12-13
-------------------------

 - fix problem in requirements that would result in conflicting SQLAlchemy
    versions

0.2.4 released 2011-11-09
-------------------------
 - **BC BREAK**: changing LookupMixin.test_create() to .testing_create()
 - convert sql processing to use generators
 - add lib/helpers.py:clear_db_data(), only postgres supported currently

0.2.3 released 2011-07-16
-----------------------------
 - Facilitate use by non-default SA engine.  Enables a project to have two
    DB connections and hence two SA sessions, and still be able to use this lib.

0.2.2 released 2011-05-19
-----------------------------
 - same as 0.2.1 (accidental release bump)

0.2.1 released 2011-05-19
-----------------------------
 - remove explicit SQLAlchemy version since savalidation will install it


